# php-5


1 question-> 1.php

2 question-> 2.php

3 question-> 3.php

4 question-> 4.php

5 question-> 5.php

rest files for support
