<?php
$n=rand(2,9);
echo $n*$n;
?>