<?php
date_default_timezone_set("Asia/Kolkata");
echo date('h:i:s A');
?>